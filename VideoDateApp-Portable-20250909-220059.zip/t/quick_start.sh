#!/bin/bash
# Quick start script for Video Dating App

echo "🚀 Starting Video Dating App..."
echo ""
echo "This will open two terminal windows:"
echo "  1. Backend server (FastAPI)"
echo "  2. Frontend server (React)"
echo ""

# Check if setup was run
if [ ! -d "backend/venv" ]; then
    echo "⚠️  Setup not detected. Running setup first..."
    ./setup_dev_environment.sh
fi

# Function to start backend
start_backend() {
    echo "🔧 Starting backend server..."
    cd backend
    source venv/bin/activate
    python3 main_fixed.py
}

# Function to start frontend
start_frontend() {
    sleep 3  # Wait for backend to start
    echo "🎨 Starting frontend server..."
    cd frontend
    npm start
}

# Start backend in background
start_backend &
BACKEND_PID=$!

# Start frontend
start_frontend &
FRONTEND_PID=$!

echo ""
echo "✅ Both servers starting..."
echo ""
echo "📱 Your app will be available at:"
echo "   🎨 Frontend: http://localhost:3000"
echo "   🔧 Backend:  http://localhost:8004"
echo ""
echo "Press Ctrl+C to stop both servers"

# Wait for user to stop
wait $BACKEND_PID $FRONTEND_PID
